import { db, collection, addDoc, getDocs, query, orderBy, limit, serverTimestamp, doc, updateDoc, deleteDoc } from './firebase';

export function euclideanDistance(desc1: number[], desc2: number[]): number {
  if (desc1.length !== desc2.length) return Infinity;
  let sum = 0;
  for (let i = 0; i < desc1.length; i++) {
    const diff = desc1[i] - desc2[i];
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}

export async function registerUser(payload: { name: string, mobile: string, descriptor: number[] }) {
  const newUser = {
    ...payload,
    status: 'active',
    registrationDate: serverTimestamp(),
  };
  const docRef = await addDoc(collection(db, 'users'), newUser);
  return { success: true, userId: docRef.id };
}

export async function verifyUser(descriptor: number[]) {
  const snapshot = await getDocs(collection(db, 'users'));
  let bestMatch: any = null;
  let minDistance = Infinity;

  snapshot.forEach((doc) => {
    const userData = doc.data();
    if (userData.descriptor && Array.isArray(userData.descriptor)) {
      const distance = euclideanDistance(descriptor, userData.descriptor);
      if (distance < minDistance) {
        minDistance = distance;
        bestMatch = { id: doc.id, ...userData };
      }
    }
  });

  const THRESHOLD = 0.5;
  if (bestMatch && minDistance <= THRESHOLD) {
    if (bestMatch.status === 'blocked') {
      return { 
        success: true, match: true, 
        user: { id: bestMatch.id, name: bestMatch.name, status: 'blocked' },
        distance: minDistance 
      };
    }
    await addDoc(collection(db, 'attendance'), {
      userId: bestMatch.id,
      name: bestMatch.name,
      timestamp: serverTimestamp(),
      status: 'Verified',
      confidence: 1 - minDistance
    });
    return { 
      success: true, match: true, 
      user: { id: bestMatch.id, name: bestMatch.name, status: bestMatch.status || 'active' },
      distance: minDistance 
    };
  } else {
    return { success: true, match: false, distance: minDistance };
  }
}

export async function getAttendance() {
  const logsQuery = query(collection(db, 'attendance'), orderBy('timestamp', 'desc'), limit(50));
  const snapshot = await getDocs(logsQuery);
  return snapshot.docs.map((docItem) => {
    const data = docItem.data();
    return { id: docItem.id, ...data, timestamp: data.timestamp ? data.timestamp.toDate().toISOString() : null };
  });
}

export async function getUsers() {
  const usersQuery = query(collection(db, 'users'), orderBy('registrationDate', 'desc'), limit(50));
  const snapshot = await getDocs(usersQuery);
  return snapshot.docs.map((docItem) => {
    const data = docItem.data();
    return { id: docItem.id, name: data.name, mobile: data.mobile, status: data.status || 'active', registrationDate: data.registrationDate ? data.registrationDate.toDate().toISOString() : null };
  });
}

export async function updateUserStatus(id: string, status: string) {
  const userRef = doc(db, 'users', id);
  await updateDoc(userRef, { status });
  return { success: true };
}

export async function deleteUser(id: string) {
  const userRef = doc(db, 'users', id);
  await deleteDoc(userRef);
  return { success: true };
}

export async function deleteAttendance(id: string) {
  const logRef = doc(db, 'attendance', id);
  await deleteDoc(logRef);
  return { success: true };
}
