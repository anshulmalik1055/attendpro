import React, { useState, useEffect } from 'react';
import { UserPlus, ScanFace, LayoutDashboard, ShieldCheck, Settings, Phone, MessageCircle, Mail, X } from 'lucide-react';
import RegistrationPage from './components/RegistrationPage';
import VerificationPage from './components/VerificationPage';
import AdminDashboard from './components/AdminDashboard';

export default function App() {
  const [activeTab, setActiveTab] = useState<'verify' | 'register' | 'admin'>('verify');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans selection:bg-indigo-500/30 flex flex-col overflow-x-hidden">
      {/* Professional Fixed Header */}
      <header className="fixed w-full top-0 left-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-600/20">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-base sm:text-xl font-bold bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent truncate max-w-[120px] sm:max-w-none">
              FaceAttend Pro
            </h1>
          </div>
          
          <div className="relative">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-lg bg-slate-800/50 text-slate-300 border border-slate-700/50 hover:bg-slate-700 hover:text-white transition-colors flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
            >
              <Settings className="w-5 h-5" />
            </button>
            
            {isMenuOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setIsMenuOpen(false)}></div>
                <div className="absolute right-0 mt-2 w-48 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl py-2 z-50 flex flex-col overflow-hidden">
                  <button
                    onClick={() => { setActiveTab('verify'); setIsMenuOpen(false); }}
                    className={`px-4 py-3 text-sm text-left flex items-center gap-3 transition-colors ${activeTab === 'verify' ? 'bg-slate-700/50 text-indigo-400 font-medium' : 'text-slate-300 hover:bg-slate-700/30 hover:text-slate-200'}`}
                  >
                    <ScanFace className="w-4 h-4" /> Verify
                  </button>
                  <button
                    onClick={() => { setActiveTab('register'); setIsMenuOpen(false); }}
                    className={`px-4 py-3 text-sm text-left flex items-center gap-3 transition-colors ${activeTab === 'register' ? 'bg-slate-700/50 text-indigo-400 font-medium' : 'text-slate-300 hover:bg-slate-700/30 hover:text-slate-200'}`}
                  >
                    <UserPlus className="w-4 h-4" /> Register
                  </button>
                  <div className="h-px bg-slate-700/50 my-1 mx-2"></div>
                  <button
                    onClick={() => { setActiveTab('admin'); setIsMenuOpen(false); }}
                    className={`px-4 py-3 text-sm text-left flex items-center gap-3 transition-colors ${activeTab === 'admin' ? 'bg-slate-700/50 text-indigo-400 font-medium' : 'text-slate-300 hover:bg-slate-700/30 hover:text-slate-200'}`}
                  >
                    <LayoutDashboard className="w-4 h-4" /> Admin Login
                  </button>
                  <button
                    onClick={() => { setIsContactModalOpen(true); setIsMenuOpen(false); }}
                    className="px-4 py-3 text-sm text-left flex items-center gap-3 transition-colors text-slate-300 hover:bg-slate-700/30 hover:text-slate-200"
                  >
                    <Phone className="w-4 h-4" /> Contact Developer
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-8 md:py-12 mt-16 flex flex-col items-center justify-center">
        <div className="w-full">
          {activeTab === 'verify' && <VerificationPage />}
          {activeTab === 'register' && <RegistrationPage />}
          {activeTab === 'admin' && <AdminDashboard />}
        </div>
      </main>

      {/* Footer */}
      <footer className="py-6 text-center text-sm text-slate-500 border-t border-slate-800/50">
        All Rights Reserved. FaceAttend Pro. AI-Powered Security. &copy; 2026.
      </footer>

      {/* Contact Developer Modal */}
      {isContactModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" onClick={() => setIsContactModalOpen(false)}></div>
          <div className="relative bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between p-5 border-b border-slate-800">
              <h3 className="text-lg font-semibold text-slate-100 flex items-center gap-2">
                <Phone className="w-5 h-5 text-indigo-400" />
                Contact Developer
              </h3>
              <button
                onClick={() => setIsContactModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <a
                href="https://wa.me/916283563016?text=Hii"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 w-full p-4 rounded-xl bg-green-500/10 border border-green-500/20 hover:bg-green-500/20 transition-colors group"
              >
                <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-400 group-hover:scale-110 transition-transform">
                  <MessageCircle className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-medium text-slate-200">WhatsApp</div>
                  <div className="text-xs text-slate-400">+91 6283563016</div>
                </div>
              </a>
              
              <a
                href="mailto:faceattendsupport@gmail.com"
                className="flex items-center gap-4 w-full p-4 rounded-xl bg-blue-500/10 border border-blue-500/20 hover:bg-blue-500/20 transition-colors group"
              >
                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                  <Mail className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <div className="text-sm font-medium text-slate-200">Email Support</div>
                  <div className="text-xs text-slate-400">faceattendsupport@gmail.com</div>
                </div>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
