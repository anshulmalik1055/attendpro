export interface User {
  id: string;
  name: string;
  mobile: string;
  registrationDate: string;
  status?: 'active' | 'blocked';
}

export interface AttendanceLog {
  id: string;
  userId: string;
  name: string;
  timestamp: string;
  status: string;
  confidence: number;
}
