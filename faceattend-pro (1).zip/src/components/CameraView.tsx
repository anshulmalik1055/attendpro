import React, { useRef, useImperativeHandle, forwardRef, useState, useEffect } from 'react';
import Webcam from 'react-webcam';
import { Camera, CameraOff, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { loadModels } from '../lib/faceApiUtils';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface CameraViewProps {
  isScanning?: boolean;
  onUserMedia?: () => void;
  onUserMediaError?: (e: string | DOMException) => void;
}

export interface CameraViewRef {
  getVideoElement: () => HTMLVideoElement | null;
}

const CameraView = forwardRef<CameraViewRef, CameraViewProps>(
  ({ isScanning = false, onUserMedia, onUserMediaError }, ref) => {
    const webcamRef = useRef<Webcam>(null);
    const [cameraActive, setCameraActive] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
      // Pre-load models in the background as soon as the camera view is rendered
      loadModels().catch(console.error);
    }, []);

    useImperativeHandle(ref, () => ({
      getVideoElement: () => webcamRef.current?.video || null,
    }));

    const handleUserMedia = () => {
      setCameraActive(true);
      setError(null);
      if (onUserMedia) onUserMedia();
    };

    const handleUserMediaError = (e: string | DOMException) => {
      setCameraActive(false);
      setError('Camera access denied or unavailable.');
      if (onUserMediaError) onUserMediaError(e);
    };

    return (
      <div className="relative w-full max-w-md mx-auto aspect-[3/4] sm:aspect-square md:aspect-[4/3] rounded-2xl overflow-hidden bg-slate-900 border border-slate-700 shadow-2xl flex items-center justify-center">
        {error ? (
          <div className="flex flex-col items-center justify-center text-rose-400 p-6 text-center space-y-4">
            <CameraOff className="w-12 h-12" />
            <p className="text-sm font-medium">{error}</p>
            <button 
              onClick={() => setError(null)}
              className="mt-4 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-200 text-sm transition-colors flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" /> Try Again
            </button>
          </div>
        ) : (
          <Webcam
            ref={webcamRef}
            audio={false}
            disablePictureInPicture={false}
            forceScreenshotSourceSize={false}
            imageSmoothing={true}
            screenshotQuality={0.92}
            screenshotFormat="image/jpeg"
            videoConstraints={{ facingMode: "user" }}
            onUserMedia={handleUserMedia}
            onUserMediaError={handleUserMediaError}
            className={cn(
              "absolute inset-0 w-full h-full object-cover transition-opacity duration-500",
              cameraActive ? "opacity-100" : "opacity-0"
            )}
            mirrored={true}
          />
        )}

        {/* Loading Overlay */}
        {!cameraActive && !error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 space-y-4 bg-slate-900/80 backdrop-blur-sm z-10">
            <Camera className="w-10 h-10 animate-pulse text-indigo-500" />
            <span className="text-sm tracking-wide uppercase font-medium">Initializing Camera...</span>
          </div>
        )}

        {/* Frame Guide */}
        {cameraActive && !error && (
          <div className="absolute inset-0 pointer-events-none z-20 flex items-center justify-center">
            {/* Dark overlay with clear oval cutout */}
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <mask id="face-mask">
                  <rect width="100%" height="100%" fill="white" />
                  <ellipse cx="50%" cy="50%" rx="35%" ry="45%" fill="black" />
                </mask>
              </defs>
              <rect width="100%" height="100%" fill="rgba(15, 23, 42, 0.6)" mask="url(#face-mask)" />
            </svg>
            
            {/* Glowing Oval Border */}
            <motion.div 
              className={cn(
                "absolute w-[70%] h-[90%] rounded-[50%] border-2 transition-colors duration-300",
                isScanning ? "border-indigo-400 shadow-[0_0_30px_rgba(99,102,241,0.6)]" : "border-slate-400/50"
              )}
              animate={isScanning ? { scale: [1, 1.02, 1], opacity: [0.8, 1, 0.8] } : {}}
              transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
            />
          </div>
        )}

        {/* Scanning Progress/Status Overlay */}
        <AnimatePresence>
          {isScanning && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute bottom-6 left-0 right-0 flex justify-center z-30"
            >
              <div className="bg-indigo-600/90 backdrop-blur text-white px-6 py-2.5 rounded-full font-medium text-sm flex items-center gap-3 shadow-lg shadow-indigo-900/50 border border-indigo-400/30">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Analyzing Face...
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }
);

CameraView.displayName = 'CameraView';
export default CameraView;
