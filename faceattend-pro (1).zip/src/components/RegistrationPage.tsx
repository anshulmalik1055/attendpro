import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { UserPlus, ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';
import CameraView, { CameraViewRef } from './CameraView';
import { extractFaceDescriptor } from '../lib/faceApiUtils';

export default function RegistrationPage() {
  const [step, setStep] = useState<1 | 2>(1);
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const cameraRef = useRef<CameraViewRef>(null);

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) {
      setError('Please enter a valid name.');
      return;
    }
    if (mobile.trim().length < 10) {
      setError('Please enter a valid mobile number.');
      return;
    }
    setError(null);
    setStep(2);
  };

  const handleRegister = async () => {
    setIsScanning(true);
    setError(null);

    // Force React to paint the "Scanning..." UI immediately before face-api blocks the main thread
    await new Promise(resolve => setTimeout(resolve, 50));

    try {
      const videoEl = cameraRef.current?.getVideoElement();
      if (!videoEl) {
        throw new Error('Camera not ready');
      }

      const { descriptor, error: faceError } = await extractFaceDescriptor(videoEl);
      
      if (faceError || !descriptor || descriptor.length === 0) {
        throw new Error(faceError || 'Could not detect face. Ensure good lighting.');
      }

      const response = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, mobile, descriptor }),
      });

      const data = await response.json();
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Registration failed');
      }

      setSuccess(true);
      setTimeout(() => {
        // Reset form
        setStep(1);
        setName('');
        setMobile('');
        setSuccess(false);
      }, 3000);

    } catch (err: any) {
      setError(err.message || 'An error occurred during registration.');
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="max-w-md mx-auto w-full p-4 sm:p-6 bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-400 mb-4">
          <UserPlus className="w-6 h-6" />
        </div>
        <h2 className="text-2xl font-bold text-slate-100">New Registration</h2>
        <p className="text-sm text-slate-400 mt-2">Set up your facial recognition profile.</p>
      </div>

      <AnimatePresence mode="wait">
        {step === 1 ? (
          <motion.form 
            key="step1"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            onSubmit={handleNext}
            className="space-y-5"
          >
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Jane Doe"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1.5">Mobile Number</label>
              <input
                type="tel"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                placeholder="e.g. +1 234 567 8900"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all"
              />
            </div>

            {error && (
              <div className="flex items-start gap-2 text-rose-400 bg-rose-400/10 p-3 rounded-lg text-sm">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <p>{error}</p>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg px-4 py-3.5 font-medium transition-colors flex items-center justify-center gap-2 mt-4"
            >
              Continue to Face Scan <ArrowRight className="w-4 h-4" />
            </button>
          </motion.form>
        ) : (
          <motion.div 
            key="step2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="space-y-6"
          >
            <CameraView ref={cameraRef} isScanning={isScanning} />
            
            {error && (
              <div className="flex items-start gap-2 text-rose-400 bg-rose-400/10 p-3 rounded-lg text-sm">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <p>{error}</p>
              </div>
            )}

            {success ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-3 justify-center text-emerald-400 bg-emerald-400/10 p-4 rounded-xl font-medium"
              >
                <CheckCircle2 className="w-6 h-6" />
                Registration Successful!
              </motion.div>
            ) : (
              <div className="flex gap-3">
                <button
                  onClick={() => setStep(1)}
                  disabled={isScanning}
                  className="flex-1 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg px-4 py-3.5 font-medium transition-colors disabled:opacity-50"
                >
                  Back
                </button>
                <button
                  onClick={handleRegister}
                  disabled={isScanning}
                  className="flex-[2] bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg px-4 py-3.5 font-medium transition-colors disabled:opacity-50 relative overflow-hidden"
                >
                  {isScanning ? 'Processing...' : 'Capture & Register'}
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
