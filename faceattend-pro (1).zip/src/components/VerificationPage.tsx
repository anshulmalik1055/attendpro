import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ScanFace, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react';
import CameraView, { CameraViewRef } from './CameraView';
import { extractFaceDescriptor } from '../lib/faceApiUtils';

export default function VerificationPage() {
  const [isScanning, setIsScanning] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error' | 'blocked'>('idle');
  const [message, setMessage] = useState('');
  const cameraRef = useRef<CameraViewRef>(null);

  const handleVerify = async () => {
    setIsScanning(true);
    setStatus('idle');
    setMessage('');

    // Force React to paint the "Scanning..." UI immediately before face-api blocks the main thread
    await new Promise(resolve => setTimeout(resolve, 50));

    try {
      const videoEl = cameraRef.current?.getVideoElement();
      if (!videoEl) {
        throw new Error('Camera not ready');
      }

      const { descriptor, error: faceError } = await extractFaceDescriptor(videoEl);
      
      if (faceError || !descriptor || descriptor.length === 0) {
        throw new Error(faceError || 'No face detected. Please try again.');
      }

      const response = await fetch('/api/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ descriptor }),
      });

      const data = await response.json();
      
      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Verification failed on server.');
      }

      if (data.match && data.user) {
        if (data.user.status === 'blocked') {
          setStatus('blocked');
          setMessage('Your account is Blocked by admin please contact your admin on this number 6283563016');
        } else {
          setStatus('success');
          setMessage(`Welcome back, ${data.user.name}!`);
          setTimeout(() => setStatus('idle'), 4000);
        }
      } else {
        setStatus('error');
        setMessage('user not found please register');
      }

    } catch (err: any) {
      setStatus('error');
      setMessage(err.message || 'An error occurred during verification.');
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="max-w-md mx-auto w-full p-4 sm:p-6 bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-400 mb-4">
          <ScanFace className="w-6 h-6" />
        </div>
        <h2 className="text-2xl font-bold text-slate-100">Face Verification</h2>
        <p className="text-sm text-slate-400 mt-2">Scan your face for instant access.</p>
      </div>

      <div className="space-y-6 relative">
        <CameraView ref={cameraRef} isScanning={isScanning} />

        <AnimatePresence>
          {status !== 'idle' && (
            <motion.div 
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="absolute inset-0 z-40 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm rounded-2xl"
            >
              <div className={`flex flex-col items-center text-center p-6 rounded-2xl max-w-[80%] ${
                status === 'success' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 
                status === 'blocked' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                'bg-rose-500/10 text-rose-400 border border-rose-500/20'
              }`}>
                {status === 'success' ? (
                  <CheckCircle2 className="w-16 h-16 mb-4" />
                ) : status === 'blocked' ? (
                  <AlertTriangle className="w-16 h-16 mb-4" />
                ) : (
                  <XCircle className="w-16 h-16 mb-4" />
                )}
                <h3 className="text-xl font-bold mb-2">
                  {status === 'success' ? 'Face Verified' : status === 'blocked' ? 'Account Blocked' : 'Access Denied'}
                </h3>
                <p className="text-sm opacity-90">{message}</p>
                {(status === 'error' || status === 'blocked') && (
                  <button 
                    onClick={() => setStatus('idle')}
                    className="mt-6 px-6 py-2 bg-slate-800 text-slate-200 rounded-lg text-sm hover:bg-slate-700 transition-colors"
                  >
                    Try Again
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <button
          onClick={handleVerify}
          disabled={isScanning || status === 'success'}
          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg px-4 py-4 font-medium transition-colors disabled:opacity-50 text-lg shadow-lg shadow-indigo-600/20"
        >
          {isScanning ? 'Verifying...' : 'Scan Face'}
        </button>
      </div>
    </div>
  );
}
