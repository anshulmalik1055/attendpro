import React, { useEffect, useState } from 'react';
import { Users, Clock, Loader2, UserCheck, Shield, Trash2, Ban, CheckCircle, Download } from 'lucide-react';
import { AttendanceLog, User } from '../types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export default function AdminDashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const [logs, setLogs] = useState<AttendanceLog[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'attendance' | 'users'>('attendance');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'admin' && password === 'anshul2004') {
      setIsAuthenticated(true);
      setLoginError('');
    } else {
      setLoginError('Invalid username or password');
    }
  };

  useEffect(() => {
    if (!isAuthenticated) return;

    const fetchData = async () => {
      setLoading(true);
      try {
        const [logsRes, usersRes] = await Promise.all([
          fetch('/api/attendance'),
          fetch('/api/users')
        ]);
        if (logsRes.ok) setLogs(await logsRes.json());
        if (usersRes.ok) setUsers(await usersRes.json());
      } catch (error) {
        console.error('Failed to fetch dashboard data', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [isAuthenticated, activeTab]);

  const handleToggleBlock = async (userId: string, currentStatus: string | undefined) => {
    const newStatus = currentStatus === 'blocked' ? 'active' : 'blocked';
    try {
      const res = await fetch(`/api/users/${userId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        setUsers(users.map(u => u.id === userId ? { ...u, status: newStatus } : u));
      }
    } catch (error) {
      console.error('Failed to update status', error);
    }
  };

  const [confirmDeleteUser, setConfirmDeleteUser] = useState<string | null>(null);
  const [confirmDeleteLog, setConfirmDeleteLog] = useState<string | null>(null);

  const handleDeleteUser = async (userId: string) => {
    // Optimistic UI update
    setUsers(users.filter(u => u.id !== userId));
    setConfirmDeleteUser(null);
    
    try {
      const res = await fetch(`/api/users/${userId}`, {
        method: 'DELETE'
      });
      if (!res.ok) {
        console.error('Failed to delete user on server');
      }
    } catch (error) {
      console.error('Failed to delete user', error);
    }
  };

  const handleDeleteLog = async (logId: string) => {
    // Optimistic UI update: remove instantly from UI
    setLogs(logs.filter(l => l.id !== logId));
    setConfirmDeleteLog(null);
    
    try {
      const res = await fetch(`/api/attendance/${logId}`, {
        method: 'DELETE'
      });
      if (!res.ok) {
        // Revert if failed (optional, but good practice. For now, we assume success as requested for speed)
        console.error('Server failed to delete log');
      }
    } catch (error) {
      console.error('Failed to delete attendance log', error);
    }
  };

  const handleDownloadPDF = () => {
    const doc = new jsPDF();
    doc.text('Attendance History', 14, 15);
    
    const tableData = logs.map(log => [
      log.name,
      new Date(log.timestamp).toLocaleDateString(),
      new Date(log.timestamp).toLocaleTimeString(),
      log.status
    ]);

    autoTable(doc, {
      head: [['Name', 'Date', 'Time', 'Status']],
      body: tableData,
      startY: 20,
    });

    doc.save('attendance_history.pdf');
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto w-full p-6 sm:p-8 bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-400 mb-4">
            <Shield className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-bold text-slate-100">Admin Login</h2>
          <p className="text-sm text-slate-400 mt-2">Sign in to manage users and attendance.</p>
        </div>
        
        <form onSubmit={handleLogin} className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1.5">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all"
            />
          </div>
          {loginError && (
            <div className="text-sm text-rose-400 bg-rose-400/10 p-3 rounded-lg text-center">
              {loginError}
            </div>
          )}
          <button
            type="submit"
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg px-4 py-3.5 font-medium transition-colors mt-4"
          >
            Sign In
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto w-full p-4 sm:p-6 bg-slate-800/50 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-100 flex items-center gap-3">
            <UserCheck className="text-indigo-400" /> Admin Dashboard
          </h2>
          <p className="text-sm text-slate-400 mt-1">Manage users and view attendance logs.</p>
        </div>
        
        <div className="flex bg-slate-900 rounded-lg p-1 border border-slate-700">
          <button
            onClick={() => setActiveTab('attendance')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'attendance' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Clock className="w-4 h-4 inline mr-2" /> Attendance
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${activeTab === 'users' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <Users className="w-4 h-4 inline mr-2" /> Users
          </button>
        </div>
      </div>

      {activeTab === 'attendance' && (
        <div className="flex justify-end mb-4">
          <button
            onClick={handleDownloadPDF}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg flex items-center transition-colors shadow-sm"
          >
            <Download className="w-4 h-4 mr-2" /> Download PDF
          </button>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center p-12 text-indigo-400">
          <Loader2 className="w-8 h-8 animate-spin" />
        </div>
      ) : activeTab === 'attendance' ? (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-900/50 text-slate-300">
              <tr>
                <th className="px-4 py-3 rounded-tl-lg">Name</th>
                <th className="px-4 py-3">Time</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 rounded-tr-lg text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/50">
              {logs.length === 0 ? (
                <tr><td colSpan={4} className="px-4 py-8 text-center text-slate-500">No attendance logs found.</td></tr>
              ) : logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-700/20 transition-colors">
                  <td className="px-4 py-3 font-medium text-slate-200">{log.name}</td>
                  <td className="px-4 py-3 text-slate-400">{new Date(log.timestamp).toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      {log.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    {confirmDeleteLog === log.id ? (
                      <div className="inline-flex items-center space-x-2">
                        <button onClick={() => setConfirmDeleteLog(null)} className="text-xs text-slate-400 hover:text-slate-200 px-2 py-1">Cancel</button>
                        <button onClick={() => handleDeleteLog(log.id)} className="text-xs bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 px-2 py-1 rounded">Confirm</button>
                      </div>
                    ) : (
                      <button 
                        onClick={() => setConfirmDeleteLog(log.id)}
                        className="inline-flex items-center p-1.5 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition-colors"
                        title="Delete Log"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-900/50 text-slate-300">
              <tr>
                <th className="px-4 py-3 rounded-tl-lg">Name</th>
                <th className="px-4 py-3">Mobile</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Registered On</th>
                <th className="px-4 py-3 rounded-tr-lg text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/50">
              {users.length === 0 ? (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-500">No users registered yet.</td></tr>
              ) : users.map((user) => (
                <tr key={user.id} className="hover:bg-slate-700/20 transition-colors">
                  <td className="px-4 py-3 font-medium text-slate-200">{user.name}</td>
                  <td className="px-4 py-3 text-slate-400">{user.mobile}</td>
                  <td className="px-4 py-3">
                    {user.status === 'blocked' ? (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        Blocked
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        Active
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-slate-400">{new Date(user.registrationDate).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-right space-x-2">
                    {confirmDeleteUser === user.id ? (
                      <div className="inline-flex items-center space-x-2">
                        <button onClick={() => setConfirmDeleteUser(null)} className="text-xs text-slate-400 hover:text-slate-200 px-2 py-1">Cancel</button>
                        <button onClick={() => handleDeleteUser(user.id)} className="text-xs bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 px-2 py-1 rounded">Confirm</button>
                      </div>
                    ) : (
                      <>
                        <button 
                          onClick={() => handleToggleBlock(user.id, user.status)}
                          className={`inline-flex items-center p-1.5 rounded-lg transition-colors ${
                            user.status === 'blocked' ? 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20' : 'bg-amber-500/10 text-amber-400 hover:bg-amber-500/20'
                          }`}
                          title={user.status === 'blocked' ? "Unblock User" : "Block User"}
                        >
                          {user.status === 'blocked' ? <CheckCircle className="w-4 h-4" /> : <Ban className="w-4 h-4" />}
                        </button>
                        <button 
                          onClick={() => setConfirmDeleteUser(user.id)}
                          className="inline-flex items-center p-1.5 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition-colors"
                          title="Delete User"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
