import * as faceapi from '@vladmandic/face-api';

let isInitialized = false;

export async function loadModels() {
  if (isInitialized) return;

  const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/';
  
  try {
    // Explicitly set WebGL backend for maximum speed if available
    try {
      // @ts-ignore - tf.setBackend is valid but missing in some type definitions
      await faceapi.tf.setBackend('webgl');
      // @ts-ignore - tf.ready is valid but missing in some type definitions
      await faceapi.tf.ready();
    } catch (e) {
      console.warn('WebGL backend not available, falling back to default');
    }

    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
    ]);
    isInitialized = true;
    console.log('FaceAPI models loaded from CDN');

    // WARMUP: The first inference compiles WebGL shaders and is notoriously slow.
    // By passing a dummy canvas right after loading, we make the user's first scan instant.
    try {
      const dummyCanvas = document.createElement('canvas');
      dummyCanvas.width = 160;
      dummyCanvas.height = 160;
      const ctx = dummyCanvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, 160, 160);
        console.log('Warming up WebGL shaders...');
        await faceapi.detectSingleFace(dummyCanvas, new faceapi.TinyFaceDetectorOptions({ inputSize: 160 }))
          .withFaceLandmarks()
          .withFaceDescriptor();
        console.log('WebGL Warmup complete');
      }
    } catch (e) {
      console.warn('Warmup skipped or failed', e);
    }

  } catch (error) {
    console.error('Failed to load FaceAPI models:', error);
    throw error;
  }
}

export async function extractFaceDescriptor(videoEl: HTMLVideoElement): Promise<{ descriptor: number[], error?: string }> {
  if (!isInitialized) await loadModels();

  try {
    // Lowered inputSize to 160 for even faster processing (still accurate enough for close-up webcam)
    const detection = await faceapi.detectSingleFace(videoEl, new faceapi.TinyFaceDetectorOptions({ inputSize: 160 }))
      .withFaceLandmarks()
      .withFaceDescriptor();

    if (!detection) {
      return { descriptor: [], error: 'No face detected. Please position your face clearly in the frame.' };
    }

    // Quality check: face size relative to image
    const faceWidth = detection.detection.box.width;
    const videoWidth = videoEl.videoWidth;
    
    if (faceWidth / videoWidth < 0.25) {
       return { descriptor: [], error: 'Face too small. Please move closer to the camera.' };
    }

    // Return the float32 array as a standard JS array for JSON serialization
    return { descriptor: Array.from(detection.descriptor) };
  } catch (error) {
    console.error('Error during face detection:', error);
    return { descriptor: [], error: 'Failed to process camera feed.' };
  }
}
