import express from 'express';
import cors from 'cors';
import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, getDocs, query, orderBy, limit, serverTimestamp, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

let db: any = null;
try {
  const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
  const configRaw = fs.readFileSync(configPath, 'utf8');
  const firebaseConfig = JSON.parse(configRaw);

  const appInstance = initializeApp(firebaseConfig);
  db = getFirestore(appInstance, firebaseConfig.firestoreDatabaseId);
  console.log(`Firebase initialized for project ${firebaseConfig.projectId}, db ${firebaseConfig.firestoreDatabaseId}`);
} catch (error) {
  console.error('Failed to initialize Firebase:', error);
}

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Helper to compute Euclidean distance between two 128d descriptors
function euclideanDistance(desc1: number[], desc2: number[]): number {
  if (desc1.length !== desc2.length) return Infinity;
  let sum = 0;
  for (let i = 0; i < desc1.length; i++) {
    const diff = desc1[i] - desc2[i];
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}

// Ensure the database is initialized
function requireDb(req: express.Request, res: express.Response, next: express.NextFunction) {
  if (!db) {
    return res.status(500).json({ error: 'Database not initialized' });
  }
  next();
}

app.post('/api/register', requireDb, async (req, res) => {
  try {
    const { name, mobile, descriptor } = req.body;
    
    if (!name || !mobile || !descriptor || !Array.isArray(descriptor) || descriptor.length !== 128) {
      return res.status(400).json({ error: 'Invalid payload' });
    }

    const newUser = {
      name,
      mobile,
      descriptor,
      status: 'active',
      registrationDate: serverTimestamp(),
    };

    const docRef = await addDoc(collection(db, 'users'), newUser);
    res.json({ success: true, userId: docRef.id });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Failed to register' });
  }
});

app.post('/api/verify', requireDb, async (req, res) => {
  try {
    const { descriptor } = req.body;

    if (!descriptor || !Array.isArray(descriptor) || descriptor.length !== 128) {
      return res.status(400).json({ error: 'Invalid descriptor' });
    }

    const snapshot = await getDocs(collection(db, 'users'));
    let bestMatch: any = null;
    let minDistance = Infinity;

    snapshot.forEach((doc) => {
      const userData = doc.data();
      if (userData.descriptor && Array.isArray(userData.descriptor)) {
        const distance = euclideanDistance(descriptor, userData.descriptor);
        if (distance < minDistance) {
          minDistance = distance;
          bestMatch = { id: doc.id, ...userData };
        }
      }
    });

    const THRESHOLD = 0.5;

    if (bestMatch && minDistance <= THRESHOLD) {
      if (bestMatch.status === 'blocked') {
        return res.json({ 
          success: true, 
          match: true, 
          user: { id: bestMatch.id, name: bestMatch.name, status: 'blocked' },
          distance: minDistance 
        });
      }

      await addDoc(collection(db, 'attendance'), {
        userId: bestMatch.id,
        name: bestMatch.name,
        timestamp: serverTimestamp(),
        status: 'Verified',
        confidence: 1 - minDistance
      });

      res.json({ 
        success: true, 
        match: true, 
        user: { id: bestMatch.id, name: bestMatch.name, status: bestMatch.status || 'active' },
        distance: minDistance 
      });
    } else {
      res.json({ 
        success: true, 
        match: false, 
        distance: minDistance 
      });
    }
  } catch (error) {
    console.error('Verification error:', error);
    res.status(500).json({ error: 'Failed to verify' });
  }
});

app.get('/api/attendance', requireDb, async (req, res) => {
  try {
    const logsQuery = query(collection(db, 'attendance'), orderBy('timestamp', 'desc'), limit(50));
    const snapshot = await getDocs(logsQuery);
    const logs = snapshot.docs.map((doc) => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        timestamp: data.timestamp ? data.timestamp.toDate().toISOString() : null
      };
    });
    res.json(logs);
  } catch (error) {
    console.error('Fetch attendance error:', error);
    res.status(500).json({ error: 'Failed to fetch attendance' });
  }
});

app.get('/api/users', requireDb, async (req, res) => {
  try {
    const usersQuery = query(collection(db, 'users'), orderBy('registrationDate', 'desc'), limit(50));
    const snapshot = await getDocs(usersQuery);
    const users = snapshot.docs.map((doc) => {
      const data = doc.data();
      return {
        id: doc.id,
        name: data.name,
        mobile: data.mobile,
        status: data.status || 'active',
        registrationDate: data.registrationDate ? data.registrationDate.toDate().toISOString() : null
      };
    });
    res.json(users);
  } catch (error) {
    console.error('Fetch users error:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

app.put('/api/users/:id/status', requireDb, async (req, res) => {
  try {
    const { status } = req.body;
    const userRef = doc(db, 'users', req.params.id);
    await updateDoc(userRef, { status });
    res.json({ success: true });
  } catch (error) {
    console.error('Update status error:', error);
    res.status(500).json({ error: 'Failed to update user status' });
  }
});

app.delete('/api/users/:id', requireDb, async (req, res) => {
  try {
    const userRef = doc(db, 'users', req.params.id);
    await deleteDoc(userRef);
    res.json({ success: true });
  } catch (error) {
    console.error('Delete user error:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

app.delete('/api/attendance/:id', requireDb, async (req, res) => {
  try {
    const logRef = doc(db, 'attendance', req.params.id);
    await deleteDoc(logRef);
    res.json({ success: true });
  } catch (error) {
    console.error('Delete attendance error:', error);
    res.status(500).json({ error: 'Failed to delete attendance log' });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    // Important: for express v4, it is '*', for v5 it is '*all'. Express in package.json is 4.21.2.
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
